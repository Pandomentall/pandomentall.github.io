# TuzLimon press kit

Open `index.html` for the visual overview. Use the SVGs wherever you can; every file is vector
and scales without loss. PNGs are provided for places that can't take SVG.

## What's inside

| Folder | Contents |
|---|---|
| `logo/` | Main logo (mascot above the name): on dark, on light, transparent for dark backgrounds, transparent for light backgrounds, one-colour white and black. SVG + PNG 1200 / 2400 / 4800 px wide. |
| `logo-horizontal/` | Mascot left, name right, for headers and banners. Same four colour versions. |
| `wordmark/` | The name alone: cream, night, white, black. |
| `mascot/` | The lemon on its own (plain and with a sticker outline), app icon, round avatar (plain, and in a thin cream ring for sitting beside other studio badges). SVG + PNG 256 to 2048 px. |
| `mascot/web-icons/` | favicon.ico, favicon.svg, PNG favicons, apple-touch-icon, PWA icons, webmanifest, `<head>` snippet. |

## Which file to use

- Dark background: `logo/tuzlimon-logo-transparent-for-dark.svg`
- Light background: `logo/tuzlimon-logo-transparent-for-light.svg` (the mascot gets a dark sticker outline so the salt stays visible)
- One colour only (print, stamps, merch): `logo/tuzlimon-logo-white.svg` / `-black.svg`
- Avatars and store icons: `mascot/tuzlimon-avatar.svg`, `mascot/tuzlimon-avatar-ring.svg` (co-branding next to other studios), `mascot/tuzlimon-app-icon.svg`
- Wide, low spaces: `logo-horizontal/`

## Colours

| Name | HEX | RGB |
|---|---|---|
| Night | `#141820` | 20 24 32 |
| Cream | `#F8F1E2` | 248 241 226 |
| Lemon | `#FDE327` | 253 227 39 |
| Lemon shade | `#F8CC1A` | 248 204 26 |
| Orange | `#FC9B18` | 252 155 24 |
| Salt | `#FBF9F4` | 251 249 244 |
| Salt grey | `#B2BEC9` | 178 190 201 |

## Rules

- Clear space: keep at least the height of the headband free on every side.
- Do not change the mascot's colours, expression or proportions; do not stretch or rotate.
- Do not put the colour mascot on a light background without the sticker outline.
- Do not retype the name in another font in place of the wordmark.

## Typeface

The wordmark comes from the original Tuz Limon logo of the high-school years; its letters were
traced and redrawn as vector outlines. No font is needed to use it.
